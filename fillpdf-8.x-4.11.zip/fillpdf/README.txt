See the full documentation on drupal.org:
http://drupal.org/documentation/modules/fillpdf
