<?php

namespace Drupal\fillpdf\Component\Helper;

/**
 * Interface FillPdfMappingHelperInterface.
 *
 * @package Drupal\fillpdf\Component\Helper
 */
interface FillPdfMappingHelperInterface {

}
