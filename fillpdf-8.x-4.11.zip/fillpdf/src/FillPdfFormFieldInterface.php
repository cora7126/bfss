<?php

namespace Drupal\fillpdf;

/**
 * Interface FillPdfFormFieldInterface.
 *
 * @package Drupal\fillpdf
 */
interface FillPdfFormFieldInterface extends ExportableContentEntityInterface {

}
