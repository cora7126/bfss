<?php

namespace Drupal\fillpdf\Plugin;

use Drupal\Core\Plugin\PluginBase;

/**
 * Base class for FillPDF PdfBackend plugins.
 */
abstract class PdfBackendBase extends PluginBase implements PdfBackendInterface {

}
